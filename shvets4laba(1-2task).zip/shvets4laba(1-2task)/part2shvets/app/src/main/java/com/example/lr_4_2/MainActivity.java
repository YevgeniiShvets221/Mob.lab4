package com.example.lr_4_2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity implements ControlActivityList.OnFragmentInteractionListener {

    private FragmentManager manager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        manager = getSupportFragmentManager();
        manager.beginTransaction()
                .add(R.id.fragment,new ControlActivityList(),"frag1")
                .commit();
    }

    @Override
    public void onFragmentInteraction(String result) {

        //Создаем переменную для дальнейшей передачи ссылки
        String temp="error";

        //Проводим проверку на поступающие данные и передаем ссылку дальше
        if(result=="Ukraine"){
            temp = "https://ru.m.wikipedia.org/wiki/%D0%A4%D0%B0%D0%B9%D0%BB:Flag_of_Ukraine.svg"; //ссылка на флаг Украины
        }
        else if(result=="Poland"){
            temp = "https://ru.m.wikipedia.org/wiki/%D0%A4%D0%B0%D0%B9%D0%BB:Flag_of_Poland.svg"; //ссылка на флаг Польши
        }
        else if(result=="Belarus"){
            temp = "https://ru.m.wikipedia.org/wiki/%D0%A4%D0%B0%D0%B9%D0%BB:Flag_of_Belarus.svg"; // ссылка на флаг Белорусии
        }


        //Отправим результат дальше
        manager.beginTransaction()
                .add(R.id.fragment2,ControlActivityWeb.newInstance(temp),"frag2")
                .commit();
    }

}
